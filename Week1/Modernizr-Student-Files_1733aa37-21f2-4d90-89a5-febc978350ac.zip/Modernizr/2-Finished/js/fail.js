console.log("Your browser does not support the new date picker");

$("input[type=date]").datepicker({
	dateFormate:"mm/dd/yy"
	});